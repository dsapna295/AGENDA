import React from 'react'

const Nopage = () => {
  return (
    <div>Nopage</div>
  )
}

export default Nopage